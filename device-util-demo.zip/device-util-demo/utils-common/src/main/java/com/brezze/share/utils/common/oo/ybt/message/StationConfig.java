package com.brezze.share.utils.common.oo.ybt.message;

public class StationConfig {


    /**
     * dRotationRefer : 15
     * dHeadConfig : 221
     * dRotationNumber : 5
     * dRotationEnable : 1
     * dMotorEnable : 0
     * dAreaConfig : 3
     */
    /**
     *
     */
    private String dRotationRefer;
    /**
     *
     */
    private String dHeadConfig;
    /**
     *
     */
    private String dRotationNumber;
    /**
     *
     */
    private String dRotationEnable;
    /**
     *
     */
    private String dMotorEnable;
    /**
     *
     */
    private String dAreaConfig;

    public String getDRotationRefer() {
        return dRotationRefer;
    }

    public void setDRotationRefer(String dRotationRefer) {
        this.dRotationRefer = dRotationRefer;
    }

    public String getDHeadConfig() {
        return dHeadConfig;
    }

    public void setDHeadConfig(String dHeadConfig) {
        this.dHeadConfig = dHeadConfig;
    }

    public String getDRotationNumber() {
        return dRotationNumber;
    }

    public void setDRotationNumber(String dRotationNumber) {
        this.dRotationNumber = dRotationNumber;
    }

    public String getDRotationEnable() {
        return dRotationEnable;
    }

    public void setDRotationEnable(String dRotationEnable) {
        this.dRotationEnable = dRotationEnable;
    }

    public String getDMotorEnable() {
        return dMotorEnable;
    }

    public void setDMotorEnable(String dMotorEnable) {
        this.dMotorEnable = dMotorEnable;
    }

    public String getDAreaConfig() {
        return dAreaConfig;
    }

    public void setDAreaConfig(String dAreaConfig) {
        this.dAreaConfig = dAreaConfig;
    }
}
