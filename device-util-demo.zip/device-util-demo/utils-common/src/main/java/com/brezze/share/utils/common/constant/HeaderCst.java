package com.brezze.share.utils.common.constant;

public class HeaderCst {

    /**
     * 语言
     */
    public static final String LANGUAGE = "brezze-language";


}
