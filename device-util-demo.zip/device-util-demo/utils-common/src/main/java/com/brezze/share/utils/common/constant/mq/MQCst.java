package com.brezze.share.utils.common.constant.mq;

public class MQCst {

    /**
     * AMQP Template
     */
    public static final String RABBIT_TEMPLATE = "rabbitTemplate";
}
