package com.brezze.share.utils.common.oo.ybt.message;

public class ReceivePinboard {

    private int index;

    private int[] sn;

    private int snAsInt;

    private String snAsString;
}
